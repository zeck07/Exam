﻿ 


    $("#ddlItem").on("change", function ()
    {
        var id = $(this).val();
        var url = "Orders/GetItemPrice";

        $.ajax(  
        {  
            url: "/Orders/GetItemPrice?itemID=" + id,
            type: "GET",
            datatype: 'html',
            contentType: 'application/json; charset=utf-8',  
            success: function(data)  
            {
                //debugger;
                $('#partial_ItemPrice').html(data);
                computePrice();
            },  
            error: function()  
            {  
                alert("error");  
            }  
        });  
    });  

    $('#ddlCustomer').on("change", function () {

        $('#txtCustomerID').val($('#ddlCustomer option:selected').val());

    });


    $('#txtQty').on("change", function () {
        computePrice();
    });
    

    function computePrice() {
        var qty = $('#txtQty').val();
        var unitPrice = $('#txtUnitPrice').val();
        var totalPrice = qty * unitPrice;

        $('#txtPrice').val(totalPrice.toFixed(2));
    }

    $('#txtQty').on("click", function () {
        computePrice();
    });

    $('#dpDeliveryDate').on("change", function () {
        var deliveryDate = new Date($('#dpDeliveryDate').val());
        var yesterday = (d => new Date(d.setDate(d.getDate() - 1)))(new Date);

        if (Date.parse(deliveryDate.toDateString()) <= Date.parse(yesterday.toDateString())) {
            alert("Delivery Date should not be earlier than the current date.");
            $('#dpDeliveryDate').val('');
        }

    });
    

 

    $('#gridItem').on('change', 'input', function () {
        var qty = $(this).val();
        var rowIdx = $(this).closest('tr').index();
        var row = $(this).closest('tr');
        var unitPrice = row.find('td:eq(3) input').val();
        var price = qty * unitPrice;


        row.find('td:eq(4) input').val(price.toFixed(2));
        setItemTotal();
        
    });
    
    function saveTempItem() {
        var skuID = $('#ddlItem').val();
        var skuName = $('#ddlItem option:selected').text();
        var qty = $('#txtQty').val();
        var unitPrice = $('#txtUnitPrice').val();
        var price = $('#txtPrice').val();
        var count = $('#gridItem tbody').find('tr').length;

        $('#gridItem').append(`<tr><td class="hide"><input value="${skuID}" name="Model.ItemViewModel[${count}].skuID"></input></td><td><input value="${skuName}" name="Model.ItemViewModel[${count}].skuName" style="border:none;" readonly></input></td><td><input type="number" class="colQty" min="0" value="${qty}" name="Model.ItemViewModel[${count}].qty" style="border:none;"></input></td><td class="hide"><input value="${unitPrice}" name="Model.ItemViewModel[${count}].unitPrice"></input></td><td><input value="${price}" name="Model.ItemViewModel[${count}].price" style="border:none;text-align:right;" readonly></input></td></tr>`);
        $("#modalItem .close").click();
        setItemTotal();
    }


    function setItemTotal() {
        var totalPrice = 0;
        $('#gridItem tbody').find('tr').each(function () {
            totalPrice += parseFloat($(this).find('td input').eq(4).val());
            
          });        
        $('#gridItem tfoot').find('tr td').eq(4).text(totalPrice.toFixed(2));
        //$('#gridItem tfoot tr:eq(0) td:eq(3)').text()
    }

    
    function openNav() {
        $('#mySidebar').width('250px')
        $('#main').css('margin-left', '250px');
        $('.openbtn').css('opacity', '0');
    }

    function closeNav() {
        $('#mySidebar').width('0px')
        $('#main').css('margin-left', '0px');
        $('.openbtn').css('opacity', '100%');
    }