﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrderTakerExam.Models
{
    public class CustomerModels
    {

        public int ID { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }

        public string fullName { get; set; }

        public string mobileNumber { get; set; }
        public string city { get; set; }
        public string status { get; set; }
        public string userID { get; set; }

    }
}