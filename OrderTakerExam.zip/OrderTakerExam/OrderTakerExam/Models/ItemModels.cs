﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrderTakerExam.Models
{
    public class ItemModels
    {
        public int ID { get; set; }
        public int purchaseOrderID { get; set; }
        public int skuID { get; set; }
        public string skuCode { get; set; }
        public string skuName { get; set; }
        public int qty { get; set; }
        public double unitPrice { get; set; }
        public double price { get; set; }
    }
}