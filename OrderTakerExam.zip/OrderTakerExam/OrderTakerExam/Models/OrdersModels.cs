﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrderTakerExam.Models
{
    public class OrdersModels
    {
        public int ID { get; set; }
        public int customerID { get; set; }
        public string customerFullName { get; set; }
        public string deliveryDate{get; set;}
        public string status { get; set; }
        public double amountDue { get; set; }   
        public string isActive { get; set; }

   
    }

  
}