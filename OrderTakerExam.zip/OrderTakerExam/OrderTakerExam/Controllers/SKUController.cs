﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OrderTakerExam.Models;

namespace OrderTakerExam.Controllers
{
    public class SKUController : Controller
    {
        DAL dal = new DAL();

        public ActionResult ViewSKU()
        {
            return View(dal.getSKU());
        }

        public ActionResult NewSKU()
        {
            return View();
        }

        [HttpPost]
        public ActionResult NewSKU(SKUModels model)
        {
            if (dal.NewSKU(model))
            {
                return RedirectToAction("ViewSKU");
            }
            else
            {
                return View();
            }
        }
    }
}