﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OrderTakerExam.Models;
using System.Collections;

namespace OrderTakerExam.Controllers
{
    public class OrdersController : Controller
    {
        DAL dal = new DAL();

        // GET: Orders
        public ActionResult ViewOrders()
        {

            return View(dal.getOrders());
        }

        public ActionResult NewOrders()
        {
            ViewBag.customerList = new SelectList(dal.getCustomer(), "ID", "fullName");

            ViewBag.Item = dal.getPurchaseItems();
            ViewBag.itemList = new SelectList(dal.getSKU(), "ID", "name");
            var model = new ItemOrderModels();


            return View(model);
        }

        [HttpPost]
        public ActionResult NewOrders(ItemOrderModels model)
        {
            dal.NewOrderItems(model.ItemViewModel, model.OrderViewModel);

            return RedirectToAction("ViewOrders");
        }

      


        public ActionResult GetItemPrice(int itemID)
        {
            //var model = db.Users.find(id); // This is for example put your code to fetch record.   
            var model = dal.getSKU().Find(id => id.ID == itemID);

            return PartialView("itemPriceDtls", model);
        }

        
      
        public ActionResult ViewPartialOrdersItem()
        {
            return View();
        }
    }

  
}