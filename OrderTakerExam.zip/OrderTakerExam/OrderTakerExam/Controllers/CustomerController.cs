﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OrderTakerExam.Models;

namespace OrderTakerExam.Controllers
{
    public class CustomerController : Controller
    {
        DAL dal = new DAL();
        // GET: Customer
        public ActionResult ViewCustomer()
        {
            return View(dal.getCustomer());
        }

        public ActionResult NewCustomer()
        {
            return View();
        }
        
        [HttpPost]
        public ActionResult NewCustomer(CustomerModels model)
        {
            if(dal.NewCustomer(model))
            {
                return RedirectToAction("ViewCustomer");
            }
            else
            {
                return View();
            }
        }

        //public ActionResult EditCustomer(int id)
        //{

        //    return View("NewCustomer", dal.getCustomer().Find(i => i.ID == id));
        //}

    }
}