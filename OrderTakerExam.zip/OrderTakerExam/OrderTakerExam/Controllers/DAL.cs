﻿using OrderTakerExam.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace OrderTakerExam.Controllers
{
    public class DAL
    {
        SqlConnection connString;
        string sp_customer = "dbo.nsp_CustomerList";
        string sp_sku = "dbo.nsp_SKUList";
        string sp_orders = "dbo.nsp_OrdersList";
        DataTable dt = new DataTable();
        SqlDataReader sqlDR;
        SqlCommand cmd = new SqlCommand();
        private SqlTransaction sqlTrn;

        public DAL()
        {
            connString = setConnection();
        }

        public SqlConnection setConnection()
        {
            string constr = ConfigurationManager.ConnectionStrings["connString"].ToString();
            return new SqlConnection(constr);
        }

        #region All Related to Customer
        public List<CustomerModels> getCustomer()
        {
            dt = new DataTable();
            cmd = new SqlCommand(sp_customer, connString);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@queryType", 0);
            connString.Open();

            sqlDR = cmd.ExecuteReader();
            dt.Load(sqlDR);

            List<CustomerModels> dtls = new List<CustomerModels>();

            foreach (DataRow dr in dt.Rows)
            {
                dtls.Add(
                    new CustomerModels
                    {
                        ID = Convert.ToInt32(dr["id"].ToString()),
                        fullName = dr["fullName"].ToString(),
                        mobileNumber = dr["mobileNumber"].ToString(),
                        city = dr["city"].ToString(),
                        status = dr["status"].ToString(),
                    });
            }

            connString.Close();

            return dtls;
        }



        public bool NewCustomer(CustomerModels obj)
        {

            SqlCommand cmd = new SqlCommand(sp_customer, connString);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@firstName", obj.firstName);
            cmd.Parameters.AddWithValue("@lastName", obj.lastName);
            cmd.Parameters.AddWithValue("@mobileNumber", obj.mobileNumber);
            cmd.Parameters.AddWithValue("@city", obj.city);
            cmd.Parameters.AddWithValue("@userID", obj.userID);
            cmd.Parameters.AddWithValue("@queryType", 1);
            connString.Open();
            int i = cmd.ExecuteNonQuery();
            connString.Close();

            if (i >= 1)
            {
                return true;
            }
            else
            {

                return false;
            }
        }

        public bool EditCustomer(CustomerModels obj)
        {

            SqlCommand cmd = new SqlCommand(sp_customer, connString);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@firstName", obj.firstName);
            cmd.Parameters.AddWithValue("@lastName", obj.lastName);
            cmd.Parameters.AddWithValue("@mobileNumber", obj.mobileNumber);
            cmd.Parameters.AddWithValue("@city", obj.city);
            cmd.Parameters.AddWithValue("@userID", obj.userID);
            cmd.Parameters.AddWithValue("@queryType", 2);
            connString.Open();
            int i = cmd.ExecuteNonQuery();
            connString.Close();

            if (i >= 1)
            {
                return true;
            }
            else
            {

                return false;
            }
        }

        public bool DeleteCustomer(CustomerModels obj)
        {

            SqlCommand cmd = new SqlCommand(sp_customer, connString);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", obj.ID);
            cmd.Parameters.AddWithValue("@queryType", 3);
            connString.Open();
            int i = cmd.ExecuteNonQuery();
            connString.Close();

            if (i >= 1)
            {
                return true;
            }
            else
            {

                return false;
            }
        }

        #endregion


        #region All Related to SKU
        public List<SKUModels> getSKU()
        {
            dt = new DataTable();
            cmd = new SqlCommand(sp_sku, connString);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@queryType", 0);
            connString.Open();

            sqlDR = cmd.ExecuteReader();
            dt.Load(sqlDR);

            List<SKUModels> dtls = new List<SKUModels>();

            foreach (DataRow dr in dt.Rows)
            {
                dtls.Add(
                    new SKUModels
                    {
                        name = dr["name"].ToString(),
                        code = dr["code"].ToString(),
                        unitPrice = dr["unitPrice"].ToString(),
                        status = dr["status"].ToString(),
                        ID = Convert.ToInt32(dr["ID"])
                    });
            }

            connString.Close();
            return dtls;
        }

        public bool NewSKU(SKUModels obj)
        {

            SqlCommand cmd = new SqlCommand(sp_sku, connString);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", obj.name);
            cmd.Parameters.AddWithValue("@code", obj.code);
            cmd.Parameters.AddWithValue("@unitPrice", obj.unitPrice);
            cmd.Parameters.AddWithValue("@queryType", 1);
            connString.Open();
            int i = cmd.ExecuteNonQuery();
            connString.Close();

            if (i >= 1)
            {
                return true;
            }
            else
            {

                return false;
            }
        }

        public bool EditSKU(SKUModels obj)
        {

            SqlCommand cmd = new SqlCommand(sp_customer, connString);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", obj.name);
            cmd.Parameters.AddWithValue("@code", obj.code);
            cmd.Parameters.AddWithValue("@unitPrice", obj.unitPrice);
            cmd.Parameters.AddWithValue("@queryType", 2);
            connString.Open();
            int i = cmd.ExecuteNonQuery();
            connString.Close();

            if (i >= 1)
            {
                return true;
            }
            else
            {

                return false;
            }
        }

        public bool DeletetSKU(SKUModels obj)
        {

            SqlCommand cmd = new SqlCommand(sp_customer, connString);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", obj.ID);
            cmd.Parameters.AddWithValue("@queryType", 3);
            connString.Open();
            int i = cmd.ExecuteNonQuery();
            connString.Close();

            if (i >= 1)
            {
                return true;
            }
            else
            {

                return false;
            }
        }

        #endregion

        #region All Related to Orders
        public List<OrdersModels> getOrders()
        {
            dt = new DataTable();
            cmd = new SqlCommand(sp_orders, connString);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@queryType", 0);
            connString.Open();

            sqlDR = cmd.ExecuteReader();
            dt.Load(sqlDR);

            List<OrdersModels> dtls = new List<OrdersModels>();

            foreach (DataRow dr in dt.Rows)
            {
                dtls.Add(
                    new OrdersModels
                    {
                        customerFullName = dr["customerFullName"].ToString(),
                        customerID = Convert.ToInt32(dr["customerID"]),
                        deliveryDate = dr["deliveryDate"].ToString(),
                        status = dr["status"].ToString(),
                        amountDue = Convert.ToDouble(dr["amtDue"]),
                        ID = Convert.ToInt32(dr["ID"])
                    });
            }

            connString.Close();
            return dtls;
        }

        public List<ItemModels> getPurchaseItems(int purchaseOrderID = 0)
        {
            dt = new DataTable();
            cmd = new SqlCommand(sp_orders, connString);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@purchaseOrderID", purchaseOrderID);
            cmd.Parameters.AddWithValue("@queryType", 4);
            connString.Open();

            sqlDR = cmd.ExecuteReader();
            dt.Load(sqlDR);

            List<ItemModels> dtls = new List<ItemModels>();

            foreach (DataRow dr in dt.Rows)
            {
                dtls.Add(
                    new ItemModels
                    {
                        purchaseOrderID = Convert.ToInt32(dr["purchaseOrderID"]),
                        skuID = Convert.ToInt32(dr["skuID"]),
                        skuName = dr["skuName"].ToString(),
                        qty = Convert.ToInt32(dr["qty"].ToString()),
                        price = Convert.ToDouble(dr["price"])
                    });
            }
            connString.Close();

            return dtls;
        }

        public bool NewOrderItems(List<ItemModels> item, OrdersModels order)
        {

            try
            {
                int purchaseOrderID = 0;
                connString.Open();
                //save order
                cmd = new SqlCommand(sp_orders, connString);
                cmd.Transaction = sqlTrn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@customerID", order.customerID);
                cmd.Parameters.AddWithValue("@deliveryDate", order.deliveryDate);
                cmd.Parameters.AddWithValue("@status", order.status);
                cmd.Parameters.AddWithValue("@amtDue", item.Sum(m => m.price));
                cmd.Parameters.AddWithValue("@queryType", 1);
                purchaseOrderID = Convert.ToInt16(cmd.ExecuteScalar());


                //save items
                foreach (ItemModels m in item)
                {
                    cmd = new SqlCommand(sp_orders, connString);
                    cmd.Transaction = sqlTrn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@purchaseOrderID", purchaseOrderID);
                    cmd.Parameters.AddWithValue("@skuID", m.skuID);
                    cmd.Parameters.AddWithValue("@qty", m.qty);
                    cmd.Parameters.AddWithValue("@price", m.price);
                    cmd.Parameters.AddWithValue("@queryType", 5);
                    cmd.ExecuteNonQuery();
                }

            
            }
            catch (SqlException sqlEx)
            {
                connString.Close();
                return false;
            }

            return true;
        }

        public bool EditOrders(OrdersModels obj)
        {

            SqlCommand cmd = new SqlCommand(sp_orders, connString);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.AddWithValue("@name", obj.name);
            //cmd.Parameters.AddWithValue("@code", obj.code);
            //cmd.Parameters.AddWithValue("@unitPrice", obj.unitPrice);
            cmd.Parameters.AddWithValue("@queryType", 2);
            connString.Open();
            int i = cmd.ExecuteNonQuery();
            connString.Close();

            if (i >= 1)
            {
                return true;
            }
            else
            {

                return false;
            }
        }

        public bool DeleteOrders(OrdersModels obj)
        {

            SqlCommand cmd = new SqlCommand(sp_customer, connString);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", obj.ID);
            cmd.Parameters.AddWithValue("@queryType", 3);
            connString.Open();
            int i = cmd.ExecuteNonQuery();
            connString.Close();

            if (i >= 1)
            {
                return true;
            }
            else
            {

                return false;
            }
        }


      
        #endregion
    }
}